$scripts="$($Env:SystemDrive)\Scripts"
New-Item $scripts -type directory -force

'[Setup]
Lang=default
Dir=C:\Program Files\Git
Group=Git
NoIcons=0
SetupType=default
Components=icons,icons\desktop,ext,ext\shellhere,ext\guihere,assoc,assoc_sh
Tasks=
PathOption=CmdTools
SSHOption=OpenSSH
CRLFOption=CRLFAlways
BashTerminalOption=MinTTY
PerformanceTweaksFSCache=Enabled
' > "$scripts\git-setup.inf"

Invoke-WebRequest -Uri "https://s3-us-west-2.amazonaws.com/devizer-public/Git-x64.exe" -OutFile "$scripts\Git-x64.exe"
Start-Process "$scripts\Git-x64.exe" @("/SILENT", "/LOG=`"c:\git-installer.log`"", "/NORESTART", "/LOADINF=`"$scripts\git-setup.inf`"") -Wait
[Environment]::SetEnvironmentVariable("Path", $env:Path + ";C:\Program Files\Git\mingw64\bin;C:\Program Files\Git\usr\bin;", [EnvironmentVariableTarget]::Machine)
