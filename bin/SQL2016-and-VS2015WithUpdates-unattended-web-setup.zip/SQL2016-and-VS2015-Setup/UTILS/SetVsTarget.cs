﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SetVsTarget
{
    using System.IO;
    using System.Xml;

    class SetVsTarget
    {
        static int Main(string[] args)
        {
            string file = args.Length > 0 ? args[0] : null;
            if (string.IsNullOrEmpty(file))
            {
                Console.WriteLine("Setup's AdminFile.XML file isnt specified");
                return 1;
            }

            var targetDir = args.Length > 1 ? args[1] : null;
            if (string.IsNullOrEmpty(targetDir))
            {
                Console.WriteLine("targetDir argument isnt specified (argument #2)");
                return 2;
            }
            
            XmlNameTable tbl = new NameTable();
            XmlNamespaceManager man = new XmlNamespaceManager(tbl);
            man.AddNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
            man.AddNamespace("xsd", "http://www.w3.org/2001/XMLSchema");
            man.AddNamespace("wix", "http://schemas.microsoft.com/wix/2011/AdminDeployment");
            XmlDocument doc = new XmlDocument(tbl);
            using(FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read))
            doc.Load(fs);

            var node = doc.DocumentElement.SelectSingleNode("//wix:BundleCustomizations", man);
            var node2 = doc.DocumentElement.SelectSingleNode("//wix:BundleCustomizations/@TargetDir", man);
            if (node2 == null)
            {
                Console.WriteLine("BundleCustomizations/@TargetDir not found. Check file");
                return 3;
            }

            try
            {
                ((XmlAttribute) node2).Value = targetDir;
                XmlTextWriter wr = new XmlTextWriter(file, Encoding.UTF8);
                wr.Formatting = Formatting.Indented;
                wr.IndentChar = ' ';
                doc.WriteTo(wr);
                wr.Close();
                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to updated BundleCustomizations/@TargetDir in file " + file + Environment.NewLine + ex);
                return 4;
            }

        }
    }
}
