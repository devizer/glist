// c-std-info2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <malloc.h>

long long NextSecond_DoublePerfomance()
{
	double i = 1;
	double inc = 0;
	double sum = 1;
	int j;
	long long prev, next;
	prev = time(NULL);
	long long perfomance = 0;
	while (1)
	{
		inc += 1.0;
		for (j = 142857; j > 0; j--)
		{
			sum += 1.0 / i + i*(i + 0.5);
			i += 1.0 + inc;
		}

		perfomance++;
		next = time(NULL);
		if (next != prev) break;
	}

	double copy = sum + inc;
	return perfomance;
}

long long NextSecond_FloatPerfomance()
{
	float i = 1;
	float inc = 0;
	float sum = 1;
	int j;
	long long prev, next;
	prev = time(NULL);
	long long perfomance = 0;
	while (1)
	{
		inc += 1.0f;
		for (j = 142857; j > 0; j--)
		{
			sum += 1.0f / i + i*(i + 0.5f);
			i += 1.0f + inc;
		}

		perfomance += 1;
		next = time(NULL);
		if (next != prev) break;
	}

	float copy = sum + inc;
	return perfomance;
}

int NextSecond_Memory(long long * from, long long * to, int count)
{
	long long *f, *t;
	int i;
	long long prev, next;
	prev = time(NULL);
	long sum = 0;
	while (1)
	{
		f = from;
		t = to;
		for (i = count; i > 0; i--)
			*(t++) = *(f++);

		sum++;
		next = time(NULL);
		if (next != prev) break;
	}

	return sum;
}

int main(void)
{
	unsigned short x = 1;
	int *ip;
	printf("  Endianless .......... %s\n", *((unsigned char *)&x) == 0 ? "big-endian" : "little-endian");
	printf("  pointer size ........ %ld\n", sizeof(ip));
	printf("  long long size ...... %d\n", sizeof(long long));
	printf("  long size ........... %d\n", sizeof(long));
	printf("  int size ............ %d\n", sizeof(int));

	int nBytes = 10 * 1024 * 1024;
	int n = nBytes / sizeof(long long);
	long long *source = (long long *)malloc(n * sizeof(long long));
	long long *copy = (long long *)malloc(n * sizeof(long long));

	int i;
	for (i = 0; i<n; i++)
		*(source + i) = i;

	long long *from, *to;

	from = source;
	to = copy;
	long memPerfomance = NextSecond_Memory(source, copy, n);
	memPerfomance = NextSecond_Memory(source, copy, n);
	long kb_per_second = ((long)nBytes / 1024) * ((long)memPerfomance);
	printf("  mem copy  ........... %ld KB/sec \n", kb_per_second);

	long long megaOps;
	megaOps = NextSecond_DoublePerfomance();
	megaOps = NextSecond_DoublePerfomance();
	printf("  double perf ......... %ld mega ops \n", (long)((float)(megaOps) / 1024.0f));

	megaOps = NextSecond_FloatPerfomance();
	megaOps = NextSecond_FloatPerfomance();
	printf("  float perf .......... %ld mega ops \n", (long)((float)(megaOps) / 1024.0f));


	return 0;

}


