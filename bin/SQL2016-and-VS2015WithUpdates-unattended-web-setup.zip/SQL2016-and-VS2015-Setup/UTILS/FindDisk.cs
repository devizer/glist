﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FindDisk
{
    using System.Diagnostics;
    using System.IO;
    using System.Linq;
    using System.Runtime.InteropServices;

    // command line options:
    //    debug size
    //    debug speed
    //    size
    //    speed
    class FindDisk
    {
        [DllImport("Kernel32.dll")]
        static extern bool FlushFileBuffers(IntPtr hFile);

        static void Main(string[] args)
        {
            Func<string, bool> has = s => args.Any(x => x.ToLower().Equals(s));
            bool isDebug = has("debug");
            bool isSpeed = has("speed");
            bool isSize = has("size") || !isSpeed;
            if (isSize)
                ShowLargestDisk(isDebug);
            else
                ShowFastestDisk(isDebug);

        }

        private static void ShowFastestDisk(bool isDebug)
        {
            string ret = "C:\\";
            Try(() => ret = Path.GetPathRoot(Environment.SystemDirectory));
            Try(() =>
            {
                Dictionary<string, long> sizes = new Dictionary<string, long>();
                Dictionary<string, decimal> speeds = new Dictionary<string, decimal>();
                var drives = DriveInfo.GetDrives();
                foreach (DriveInfo driveInfo in drives)
                {
                    Try(() =>
                    {
                        DirectoryInfo root = driveInfo.RootDirectory;
                        long avail = driveInfo.AvailableFreeSpace;
                        long totalFree = driveInfo.TotalFreeSpace;
                        sizes[root.FullName] = avail;
                        speeds[root.FullName] = GetSpeed(root.FullName);
                    });
                }

                if (isDebug)
                    foreach (var source in sizes.OrderByDescending(x => x.Value))
                    {
                        decimal speed;
                        speeds.TryGetValue(source.Key, out speed);
                        Console.WriteLine("  {0}: {1:n0} bytes, {2:n1} MB/s", source.Key, source.Value, speed);
                    }

                ret = speeds.OrderByDescending(x => x.Value).FirstOrDefault().Key;
            });

            if (isDebug)
                Console.Write("FASTEST: ");

            Console.WriteLine(ret);
        }

        private static decimal GetSpeed(string rootOfDisk)
        {
            string name = Path.Combine(rootOfDisk, "test-of-speed.dump");
            try
            {
                Random rnd = new Random(1);
                byte[] buffer = new byte[128*1024];
                rnd.NextBytes(buffer);

                long n = 0;
                using (FileStream fs = new FileStream(name, FileMode.Create, FileAccess.Write, FileShare.ReadWrite, buffer.Length))
                {
                    Stopwatch sw = Stopwatch.StartNew();
                    do
                    {
                        rnd.NextBytes(buffer);
                        fs.Write(buffer, 0, buffer.Length);
                        n += buffer.Length;
                    } while (sw.ElapsedMilliseconds < 10000 && n < 421*1024*1024);
                    FlushFileBuffers(fs.SafeFileHandle.DangerousGetHandle());
                }

                const int FILE_FLAG_NO_BUFFERING = 0x20000000;

                using (var reader = new FileStream(name, FileMode.Open, FileAccess.Read, FileShare.Read, buffer.Length,
                    (FileOptions) FILE_FLAG_NO_BUFFERING | FileOptions.WriteThrough))
                {
                    Stopwatch swr = Stopwatch.StartNew();
                    var t = 0L;
                    while (t < n)
                    {
                        int m = reader.Read(buffer, 0, buffer.Length);
                        t += m;
                        if (m <= 0) break;
                    }

                    var msecs = swr.ElapsedMilliseconds;
                    var speed = t/1024m/1024m/(msecs/1000m);
                    // Console.WriteLine("{0} bytes readed in {1} msecs. Speed is {2} MB/s", t, msecs, speed);
                    return speed;
                }
            }
            finally
            {
                try
                {
                    File.Delete(name);
                }
                catch
                {
                }
            }
        }

        private static void ShowLargestDisk(bool isDebug)
        {
            string ret = "C:\\";
            Try(() => ret = Path.GetPathRoot(Environment.SystemDirectory));
            Try(() =>
            {
                Dictionary<string, long> sizes = new Dictionary<string, long>();
                var drives = DriveInfo.GetDrives();
                foreach (DriveInfo driveInfo in drives)
                {
                    Try(() =>
                    {
                        DirectoryInfo root = driveInfo.RootDirectory;
                        long avail = driveInfo.AvailableFreeSpace;
                        long totalFree = driveInfo.TotalFreeSpace;
                        sizes[root.FullName] = avail;
                    });
                }

                if (isDebug)
                    foreach (var source in sizes.OrderByDescending(x => x.Value))
                        Console.WriteLine("  {0}: {1:n0} bytes", source.Key, source.Value);

                ret = sizes.OrderByDescending(x => x.Value).FirstOrDefault().Key;
            });

            if (isDebug)
                Console.Write("Largest free space: ");

            Console.WriteLine(ret);
        }

        static void Try(Action action)
        {
            try
            {
                action();

            }
            catch (Exception)
            {
            }
        }
    }
}
