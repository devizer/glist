﻿namespace Simple.Owin.Helpers
{
    internal static partial class StreamExtensions { }
}